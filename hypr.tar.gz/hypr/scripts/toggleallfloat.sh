#!/bin/bash
#     _    _ _  __ _             _    
#    / \  | | |/ _| | ___   __ _| |_  
#   / _ \ | | | |_| |/ _ \ / _` | __| 
#  / ___ \| | |  _| | (_) | (_| | |_  
# /_/   \_\_|_|_| |_|\___/ \__,_|\__| 
#                                     

hyprctl dispatch workspaceopt allfloat
notify-send "Windows on this workspace toggled to floating/tiling"
