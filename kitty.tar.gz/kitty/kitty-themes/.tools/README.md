# kitty-tools
> A bunch of useful scripts used to convert schemes and generate files.

## Process overview

1. Find a nice theme and check the licensing, is it possible to distribute the theme?
2. Generate the configuration file for **kitty**;
3. Add a new preview for the theme;
4. Update the README.md;
